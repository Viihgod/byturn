# Byturn identity and DS v1

Approved identity; component APIs and usage foundations are a proposal for owner review. This package is not a published npm library or a Figma library.

React component source: src/design-system. Import tokens.css and components.css once. Required peer/runtime dependencies are listed in package.json. Localized strings live in src/i18n/translation.json. Components require the caller to provide translated labels; they do not implement service authorization or backend persistence.

Brand variants preserve the approved vector geometry and include transparent PNG exports. Outfit is included with its SIL OFL. Project code: Apache-2.0. Third-party libraries are not vendored; install them from package.json.
